package com.hitanshudhawan.todo.utils;

/**
 * Created by hitanshu on 2/3/18.
 */

public class Constants {
    public static final String TODO_ID = "todo_id";
}
